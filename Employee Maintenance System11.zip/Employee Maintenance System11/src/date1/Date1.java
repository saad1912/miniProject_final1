package date1;
import java.util.Calendar;

public class Date1 {
    
 public static void main(String[] args) {

      // create a new calendar
      Calendar cal = (Calendar) Calendar.getInstance();
Date1 appliedDate = 10/12/2018;
      // print the current date and time
      System.out.println("" + cal.getTime());
      
// add 9 years 
      cal.add(appliedDate, 9);

      // print the modified date and time
      System.out.println("" + cal.getTime());
   }
}
