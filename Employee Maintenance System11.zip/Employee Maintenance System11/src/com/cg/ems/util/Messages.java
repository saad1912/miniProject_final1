package com.cg.ems.util;

public interface Messages {

	// By default the fields "public, static & final"
	
	// get empId and append to this field while handling the exception
	String EMPLOYEE_DOES_NOT_EXIST = "Sorry, No Data Found in DB for EmpId";
	
	String INPUT_MISMATCH = "Sorry, Input should be Only Numbers";

	String NOT_ENOUGH_LEAVE_BALANCE = "Insufficent leave balance for given Employee";

	String UNABLE_TO_COMPLETE_OPERATION = "Sorry, some error occured";

	String UNABLE_TO_ROLLBACK = "Sorry, Unable to Rollback";

	String UNABLE_TO_CLOSE_CONNECTION = "Sorry, Unable to Close Connection";
   
}
