package com.cg.ems.service;

import com.cg.ems.bean.User;
import com.cg.ems.dao.AuthenticationDaoImpl;
import com.cg.ems.dao.IAuthenticationDao;
import com.cg.ems.exception.EMSException;

public class AuthenticationServiceImpl implements IAuthenticationService {

	IAuthenticationDao authenticationDao;
	
	public AuthenticationServiceImpl() {
		authenticationDao = new AuthenticationDaoImpl();
	}

	@Override
	public User getUserByName(String userName) throws EMSException {
		// TODO Auto-generated method stub
		return authenticationDao.getUserByName(userName);
	}

	
}
