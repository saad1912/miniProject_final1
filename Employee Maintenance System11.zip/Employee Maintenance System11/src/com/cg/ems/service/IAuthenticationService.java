package com.cg.ems.service;

import com.cg.ems.bean.User;
import com.cg.ems.exception.EMSException;

public interface IAuthenticationService {

	User getUserByName(String userName) throws EMSException;
}
