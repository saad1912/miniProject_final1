package com.cg.ems.service;



import com.cg.ems.bean.Employee;
import com.cg.ems.bean.EmployeeLeave;
import com.cg.ems.exception.EMSException;

public interface IAutoApprovalService {

	boolean approveLeave(EmployeeLeave empLeave) throws EMSException;
}
