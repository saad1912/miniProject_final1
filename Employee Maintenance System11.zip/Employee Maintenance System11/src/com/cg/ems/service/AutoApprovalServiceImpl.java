package com.cg.ems.service;
import com.cg.ems.bean.Employee;
import com.cg.ems.bean.EmployeeLeave;
import com.cg.ems.dao.AutoApprovalDaoImpl;
import com.cg.ems.dao.IAutoApprovalDao;
import com.cg.ems.exception.EMSException;

public class AutoApprovalServiceImpl implements IAutoApprovalService {

	IAutoApprovalDao autoApprovalDao;
	
	public AutoApprovalServiceImpl() {
		autoApprovalDao = new AutoApprovalDaoImpl();
	}

	@Override
	public boolean approveLeave(EmployeeLeave empLeave) throws EMSException {
		// TODO Auto-generated method stub
		return autoApprovalDao.approveLeave(empLeave);
	}


	
}
