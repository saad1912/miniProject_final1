package com.cg.ems.dao;

import com.cg.ems.bean.User;
import com.cg.ems.exception.EMSException;

public interface IAuthenticationDao {

	
	User getUserByName(String userName) throws EMSException;
}
