package com.cg.ems.ui;

public class EmployeeConsole {

}
